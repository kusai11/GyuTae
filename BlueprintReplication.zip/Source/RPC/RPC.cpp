// Copyright 1998-2016 Epic Games, Inc. All Rights Reserved.

#include "RPC.h"


IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, RPC, "RPC" );
 